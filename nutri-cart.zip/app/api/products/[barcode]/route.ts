import { NextResponse } from 'next/server'
import { supabaseServer } from '@/lib/supabase/server'

export async function GET(_request: Request, { params }: { params: Promise<{ barcode: string }> }) {
  const { barcode } = await params
  const normalized = barcode.replace(/[^0-9A-Za-z-]/g, '').slice(0, 64)

  if (!normalized) return NextResponse.json({ error: 'Invalid barcode' }, { status: 400 })

  const { data, error } = await supabaseServer
    .from('products')
    .select('id, barcode, name, brand, category, serving_size, calories, protein_g, carbs_g, fat_g, fiber_g, image_url')
    .eq('barcode', normalized)
    .maybeSingle()

  if (error) {
    console.error('[v0] Product lookup failed:', error.message)
    return NextResponse.json({ error: 'Product lookup failed' }, { status: 500 })
  }

  if (!data) return NextResponse.json({ error: 'Product not found', barcode: normalized }, { status: 404 })
  return NextResponse.json({ product: data })
}
